import './App.css';
import Cart from './components/cart';


function App() {
  return (
    <div className="App">
     <Cart />
    </div>
  );
}

export default App;
