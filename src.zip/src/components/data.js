const list =[
    {
        id: 1,
        name: "Oranges",
        subname: "$0.5/piece",
        price: 0.5,
        baseprice: 0.5,
        img: "orange",
        quantity: 1,
    },
    {
        id: 2,
        name: "Lettuce",
        subname: "$1/piece",
        price: 21,
        baseprice: 1,
        img: "lettuce",
        quantity: 21,
    },
    {
        id: 3,
        name: "Strawberries",
        subname: "$4/kg",
        price: 4,
        baseprice: 4,
        img: "strawberry",
        quantity: 1,
    },
];

export default list;