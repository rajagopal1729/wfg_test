import React, {useState} from 'react';
import  '../styles/cart.css'
import list from './data';

function Cart() {
  const [cart, setCart] = useState([...list]);
   
  const handleRemove = (id) => {
    const arr = cart.filter((item) => item.id !== id);
    setCart(arr);
  };

  const handleChange = (item, d) => {
    const ind = cart.indexOf(item);
    const arr = cart;
    arr[ind].quantity += d;
    arr[ind].price = arr[ind].baseprice * arr[ind].quantity;
    if (arr[ind].quantity === 0) arr[ind].quantity = 1;
    setCart([...arr]);
  };

  const handleAdd =() => {
    let newItem = {
      id: list.length+1,
      name: "Apples",
      subname: "$0.5/piece",
      price: 0.5,
      baseprice: 0.5,
      img: "Apple",
      quantity: 1,
    };
    cart.unshift(newItem);
    setCart([...cart]);
  }

  const handleEmpty =() =>{
    cart.length=0;
    setCart([...cart]);
  }

  return (
    <div className='container'>
      <h4 className='h4'> Shopping Cart</h4>
      <div className='header_container'>
        <span className='heading_text'>items</span>
        <span className='heading_text'>quantity</span>
        <span className='heading_text'>price</span>
      </div>
      <br/>
      <hr/>
      <div>
        { cart.map((item) => {
          return (
            <div className="cart_box" key={item.id}>
              <div className="cart_name">
                <p>{item.name}<br/><span className='sub_name'>{item.subname}</span></p>
              </div>
              <div>
                <button onClick={() => handleChange(item, -1)}>-</button>
                <span>{item.quantity}</span>
                <button onClick={() => handleChange(item, 1)}>+</button>
              </div>
              <div>
                <span>{item.price}</span>
                <button onClick={() => handleRemove(item.id)}>X</button>
              </div>
            </div> 
          );
        })}
      </div>
      <div>
        <button className='add_button' onClick={() => handleAdd()}>Add Item</button>
        <button className ='empty_button' onClick={() => handleEmpty()}>Empty List</button>
      </div>
    </div>
  ); 
}

export default Cart;